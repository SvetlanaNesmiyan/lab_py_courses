class GroupLimitError(Exception):
    def __init__(self, message="Перевищено ліміт студентів у групі"):
        super().__init__(message)
